Hello World Example

Program Logic:
The GPP registers for a simple one-shot notify event that will be sent from 
the slave core(s).
